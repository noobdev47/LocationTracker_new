package com.example.locationtracker;

public class mapFR {

}
